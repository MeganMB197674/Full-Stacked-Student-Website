Megan Boyer - Final Website Project CIS100: Beginning Website Interfaces

This project represents the use of multiple HTML files with external CSS styling to design a functional and attractive website.

My website named "Full-Stacked Student," includes 4 HTML pages (Index.html, Basics.html, Tools.html, & Learning.html) and one external CSS page (Index.css).

The requirements are as follows:

- Include a description of what the page(s) output in a readme.txt.
- Include the page name in your readme.txt file.
- Use well-formatted, easy to read and commented code.
- User-Friendly Interface, including readable output, Interface is self-explaining
- Label your zip file, with the assignment name + your name.zip
